<?php
/**
 * Blog posts index — exact Clazar (clazar.io/blog) layout.
 *
 * Category tabs + keyword search filter the grid via AJAX (no reload, featured
 * post stays), and show "Nothing found" when a category/search is empty —
 * exactly like Clazar. All data comes from normal WordPress Posts.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$gt_per_page   = gt_posts_per_page();
$gt_total      = (int) wp_count_posts( 'post' )->publish;
$gt_max_pages  = (int) ceil( max( 0, $gt_total - 1 ) / $gt_per_page );
?>

<div id="primary" class="content-area gt-blog">
	<main id="main" class="site-main">

		<!-- 1. HERO -->
		<section class="gt-hero gt-bleed">
			<div class="gt-hero__inner">
				<p class="gt-hero__kicker"><?php echo esc_html( apply_filters( 'gt_hero_kicker', 'The Global Trade Insights Blog' ) ); ?></p>
				<h1 class="gt-hero__title"><?php echo esc_html( apply_filters( 'gt_hero_heading', 'Insights and tips to help you trade smarter' ) ); ?></h1>

				<form class="gt-hero__form" data-gt-hero-search>
					<input type="search" name="s" placeholder="<?php esc_attr_e( 'Search articles', 'siteorigin-corp-child' ); ?>" />
					<button type="submit"><?php esc_html_e( 'Search', 'siteorigin-corp-child' ); ?></button>
				</form>
			</div>
		</section>

		<div class="gt-container">

			<!-- 2. LATEST POST -->
			<section class="gt-latest">
				<?php
				$gt_latest = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 1, 'ignore_sticky_posts' => true, 'no_found_rows' => true ) );
				while ( $gt_latest->have_posts() ) :
					$gt_latest->the_post();
					gt_render_featured_post();
				endwhile;
				wp_reset_postdata();
				?>
			</section>

			<!-- 3. TABS + SEARCH -->
			<section class="gt-archive" id="gt-archive" data-gt-filter data-per-page="<?php echo esc_attr( $gt_per_page ); ?>">
				<div class="gt-tabs-wrap" data-gt-tabs>
					<nav class="gt-tabs" aria-label="<?php esc_attr_e( 'Blog categories', 'siteorigin-corp-child' ); ?>">
						<a class="gt-tab is-active" href="<?php echo esc_url( gt_blog_home_url() ); ?>" data-cat="0"><?php esc_html_e( 'All', 'siteorigin-corp-child' ); ?></a>
						<?php foreach ( gt_tab_categories() as $gt_cat ) : ?>
							<a class="gt-tab" href="<?php echo esc_url( get_category_link( $gt_cat->term_id ) ); ?>" data-cat="<?php echo esc_attr( $gt_cat->term_id ); ?>"><?php echo esc_html( $gt_cat->name ); ?></a>
						<?php endforeach; ?>
					</nav>
					<button class="gt-tabs__search" type="button" aria-label="<?php esc_attr_e( 'Search posts', 'siteorigin-corp-child' ); ?>" data-gt-open-search>
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
					</button>
				</div>

				<!-- Search mode (replaces tabs, like Clazar) -->
				<div class="gt-keyword" data-gt-keyword hidden>
					<input type="search" placeholder="<?php esc_attr_e( 'Search with keyword', 'siteorigin-corp-child' ); ?>" data-gt-keyword-input />
					<button type="button" aria-label="<?php esc_attr_e( 'Close search', 'siteorigin-corp-child' ); ?>" data-gt-close-search>
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
					</button>
				</div>

				<!-- 4. GRID -->
				<div class="gt-grid" id="gt-grid">
					<?php
					$gt_grid = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => $gt_per_page, 'offset' => 1, 'ignore_sticky_posts' => true, 'no_found_rows' => true ) );
					while ( $gt_grid->have_posts() ) :
						$gt_grid->the_post();
						gt_render_post_card();
					endwhile;
					wp_reset_postdata();
					?>
				</div>
				<p class="gt-nothing" data-gt-nothing hidden><?php esc_html_e( 'Nothing found', 'siteorigin-corp-child' ); ?></p>

				<div class="gt-load-more-wrap" data-gt-more-wrap <?php echo ( $gt_max_pages > 1 ) ? '' : 'hidden'; ?>>
					<button class="gt-load-more" type="button" data-gt-more><?php esc_html_e( 'View More', 'siteorigin-corp-child' ); ?></button>
				</div>
			</section>
		</div>

		<!-- 5. CTA BAND -->
		<?php if ( apply_filters( 'gt_show_cta', true ) ) : ?>
			<?php gt_render_cta(); ?>
		<?php endif; ?>

	</main>
</div>

<?php
get_footer();
