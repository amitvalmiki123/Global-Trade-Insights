/* ==========================================================================
   Global Trade Insights — Blog interactivity (Clazar behaviour)
   - Blog page: category tabs + keyword search filter the grid via AJAX
     (featured post stays, "Nothing found" when empty, View More paginates)
   - Category / tag / search pages: View More load-more
   - Single post: TOC active-state on scroll
   ========================================================================== */
(function () {
	'use strict';

	var ajaxUrl = window.gtBlog && gtBlog.ajaxUrl;

	function post(action, data) {
		var body = new FormData();
		body.append('action', action);
		Object.keys(data).forEach(function (k) { body.append(k, data[k]); });
		return fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body });
	}

	/* ---------- Blog page: live filter ---------- */
	var root = document.querySelector('[data-gt-filter]');
	if (root && ajaxUrl) {
		var grid      = root.querySelector('#gt-grid');
		var nothing   = root.querySelector('[data-gt-nothing]');
		var moreWrap  = root.querySelector('[data-gt-more-wrap]');
		var moreBtn   = root.querySelector('[data-gt-more]');
		var tabsWrap  = root.querySelector('[data-gt-tabs]');
		var tabs      = root.querySelectorAll('.gt-tab');
		var keyword   = root.querySelector('[data-gt-keyword]');
		var kwInput   = root.querySelector('[data-gt-keyword-input]');
		var openBtn   = root.querySelector('[data-gt-open-search]');
		var closeBtn  = root.querySelector('[data-gt-close-search]');
		var heroForm  = document.querySelector('[data-gt-hero-search]');
		var perPage   = parseInt(root.getAttribute('data-per-page'), 10) || 6;

		var state = { cat: 0, s: '', page: 1 };
		var timer = null;

		function setBusy(on) { root.classList.toggle('is-busy', on); }

		function load(append) {
			setBusy(true);
			post('gt_filter_posts', { cat: state.cat, s: state.s, page: state.page, perPage: perPage })
				.then(function (r) { return r.json(); })
				.then(function (res) {
					var d = res.data || {};
					if (append) { grid.insertAdjacentHTML('beforeend', d.html || ''); }
					else        { grid.innerHTML = d.html || ''; }
					var empty = !grid.children.length;
					nothing.hidden = !empty;
					grid.hidden = empty;
					moreWrap.hidden = !d.hasMore;
				})
				.catch(function () {})
				.finally(function () { setBusy(false); });
		}

		function reset() { state.page = 1; load(false); }

		tabs.forEach(function (tab) {
			tab.addEventListener('click', function (e) {
				e.preventDefault();
				tabs.forEach(function (t) { t.classList.remove('is-active'); });
				tab.classList.add('is-active');
				state.cat = parseInt(tab.getAttribute('data-cat'), 10) || 0;
				reset();
			});
		});

		function openSearch(value) {
			tabsWrap.hidden = true;
			keyword.hidden = false;
			if (typeof value === 'string') { kwInput.value = value; }
			kwInput.focus();
			state.cat = 0;
			tabs.forEach(function (t, i) { t.classList.toggle('is-active', i === 0); });
		}
		function closeSearch() {
			keyword.hidden = true;
			tabsWrap.hidden = false;
			kwInput.value = '';
			if (state.s) { state.s = ''; reset(); }
		}

		if (openBtn)  openBtn.addEventListener('click', function () { openSearch(); });
		if (closeBtn) closeBtn.addEventListener('click', closeSearch);

		if (kwInput) {
			kwInput.addEventListener('input', function () {
				clearTimeout(timer);
				timer = setTimeout(function () {
					state.s = kwInput.value.trim();
					reset();
				}, 350);
			});
		}

		if (heroForm) {
			heroForm.addEventListener('submit', function (e) {
				e.preventDefault();
				var v = heroForm.querySelector('input').value.trim();
				openSearch(v);
				state.s = v;
				reset();
				root.scrollIntoView({ behavior: 'smooth', block: 'start' });
			});
		}

		if (moreBtn) {
			moreBtn.addEventListener('click', function () {
				state.page += 1;
				load(true);
			});
		}
	}

	/* ---------- Archive pages: View More ---------- */
	var archiveBtn = document.getElementById('gt-load-more');
	var archiveGrid = document.getElementById('gt-grid');
	if (archiveBtn && archiveGrid && ajaxUrl && !root) {
		archiveBtn.addEventListener('click', function () {
			var page = (parseInt(archiveBtn.getAttribute('data-page'), 10) || 1) + 1;
			var max  = parseInt(archiveBtn.getAttribute('data-max'), 10) || 1;
			archiveBtn.classList.add('is-loading');
			post('gt_load_more', {
				page: page,
				perPage: archiveBtn.getAttribute('data-per-page') || 6,
				cat: archiveBtn.getAttribute('data-cat') || 0,
				s: archiveBtn.getAttribute('data-s') || ''
			})
				.then(function (r) { return r.text(); })
				.then(function (html) {
					archiveGrid.insertAdjacentHTML('beforeend', html);
					archiveBtn.setAttribute('data-page', page);
					if (page >= max) archiveBtn.remove();
				})
				.finally(function () { archiveBtn.classList.remove('is-loading'); });
		});
	}

	/* ---------- Single: TOC follows the heading currently in view (Clazar) ---------- */
	var toc = document.querySelector('[data-gt-toc]');
	if (toc) {
		var links = Array.prototype.slice.call(toc.querySelectorAll('a[href^="#"]'));
		var items = links
			.map(function (a) {
				var el = document.getElementById(decodeURIComponent(a.getAttribute('href').slice(1)));
				return el ? { a: a, el: el } : null;
			})
			.filter(Boolean);

		var OFFSET = 120; // px from top where a heading counts as "current"
		var current = null;

		function setActive(item) {
			if (item === current) return;
			current = item;
			links.forEach(function (l) { l.classList.remove('is-active'); });
			if (item) {
				item.a.classList.add('is-active');
				// keep the active item visible inside a long sticky TOC
				if (item.a.scrollIntoViewIfNeeded) item.a.scrollIntoViewIfNeeded(false);
			}
		}

		function update() {
			if (!items.length) return;
			var active = items[0];
			for (var i = 0; i < items.length; i++) {
				if (items[i].el.getBoundingClientRect().top - OFFSET <= 0) active = items[i];
				else break;
			}
			// at the very bottom of the page, highlight the last heading
			if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 2) active = items[items.length - 1];
			setActive(active);
		}

		var ticking = false;
		window.addEventListener('scroll', function () {
			if (!ticking) {
				window.requestAnimationFrame(function () { update(); ticking = false; });
				ticking = true;
			}
		}, { passive: true });
		window.addEventListener('resize', update);
		update();

		// smooth scroll on click
		links.forEach(function (a) {
			a.addEventListener('click', function (e) {
				var el = document.getElementById(decodeURIComponent(a.getAttribute('href').slice(1)));
				if (!el) return;
				e.preventDefault();
				window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - (OFFSET - 20), behavior: 'smooth' });
				history.replaceState(null, '', a.getAttribute('href'));
			});
		});
	}

	/* ---------- Single: copy link ---------- */
	var copyBtn = document.querySelector('[data-gt-copy]');
	if (copyBtn && navigator.clipboard) {
		copyBtn.addEventListener('click', function () {
			navigator.clipboard.writeText(copyBtn.getAttribute('data-gt-copy')).then(function () {
				copyBtn.classList.add('is-copied');
				setTimeout(function () { copyBtn.classList.remove('is-copied'); }, 1500);
			});
		});
	}
})();
