<?php
/**
 * Tag archive — Clazar-style grid (same as category pages).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
get_template_part( 'template-parts/gt-archive' );
get_footer();
