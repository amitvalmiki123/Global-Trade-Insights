<?php
/**
 * Category archive — Clazar-style grid.
 * category.php has higher priority than archive.php in the WP template
 * hierarchy, so your existing archive.php stays untouched (still used for
 * date / author archives).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
get_template_part( 'template-parts/gt-archive' );
get_footer();
