<?php
/**
 * The template for displaying archive pages.
 *
 * @license GPL 2.0
 */
get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">
			<?php if ( siteorigin_page_setting( 'page_title' ) && siteorigin_page_setting( 'overlap' ) == 'disabled' ) { ?>
				<header class="page-header">
					<?php
					the_archive_title( '<h1 class="page-title">', '</h1>' );
				the_archive_description( '<div class="taxonomy-description">', '</div>' );
				?>
				</header><!-- .page-header -->
			<?php } ?>

			<?php
			if ( is_tax( 'jetpack-portfolio-type' ) || is_tax( 'jetpack-portfolio-tag' ) ) {
				if ( have_posts() ) { ?>

					<div class="portfolio-archive-layout">
						<?php
						/* Start the Loop */
						while ( have_posts() ) {
							the_post();

							get_template_part( 'template-parts/content', 'portfolio' );
						}
						?>
					</div><?php

					if ( is_rtl() ) {
						the_posts_pagination( array(
							'prev_text' => '&rarr;',
							'next_text' => '&larr;',
						) );
					} else {
						the_posts_pagination( array(
							'prev_text' => '&larr;',
							'next_text' => '&rarr;',
						) );
					}
				} else {
					get_template_part( 'template-parts/content', 'none' );
				}
			} else {
				?>

				<?php if ( have_posts() ) : ?>

					<div class="blog-modern-grid<?php echo ( $wp_query->post_count == 1 ) ? ' single-card-grid' : ''; ?>">

						<?php while ( have_posts() ) : the_post(); ?>

							<article <?php post_class( 'blog-grid-card' ); ?>>

								<a href="<?php the_permalink(); ?>" class="blog-grid-thumb">
									<?php if ( has_post_thumbnail() ) : ?>
										<?php the_post_thumbnail( 'large' ); ?>
									<?php else : ?>
										<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/placeholder.jpg" alt="<?php the_title_attribute(); ?>">
									<?php endif; ?>
								</a>

								<div class="blog-grid-content">

									<div class="blog-grid-meta">
										<?php
										$cat = get_the_category();
										if ( ! empty( $cat ) ) :
											$cat_link = get_category_link( $cat[0]->term_id );
										?>
											<a href="<?php echo esc_url( $cat_link ); ?>" class="blog-grid-badge">
												<?php echo esc_html( $cat[0]->name ); ?>
											</a>
										<?php endif; ?>

										<span class="blog-grid-date">
											<?php echo get_the_date(); ?>
										</span>
									</div>

									<h3 class="blog-grid-title">
										<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
									</h3>

									<p class="blog-grid-excerpt">
										<?php echo wp_trim_words( get_the_excerpt(), 20 ); ?>
									</p>

									<a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>

								</div><!-- .blog-grid-content -->

							</article><!-- .blog-grid-card -->

						<?php endwhile; ?>

					</div><!-- .blog-modern-grid -->

					<div class="blog-grid-pagination">
						<?php
						the_posts_pagination( array(
							'prev_text' => '&laquo; Prev',
							'next_text' => 'Next &raquo;',
						) );
						?>
					</div>

				<?php else : ?>

					<?php get_template_part( 'template-parts/content', 'none' ); ?>

				<?php endif; ?>

			<?php } ?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_sidebar();
get_footer();
