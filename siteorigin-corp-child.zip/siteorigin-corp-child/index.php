<?php
/**
 * The main template file
 *
 * @license GPL 2.0
 */
get_header(); ?>
    <?php
$posts_page = get_option('page_for_posts');

if ( $posts_page && has_post_thumbnail( $posts_page ) ) : ?>
    <div class="blog-page-banner" data-aos="fade-in" data-aos-duration="1000">
        <?php echo get_the_post_thumbnail( $posts_page, 'full' ); ?>

        <div class="blog-banner-content">
            <h1 data-aos="fade-up"><?php echo esc_html( get_the_title( $posts_page ) ); ?></h1>
        </div>
    </div>
<?php endif; ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<?php if ( have_posts() ) : ?>

				<div class="blog-modern-grid">

					<?php while ( have_posts() ) : the_post(); ?>

						<article <?php post_class( 'blog-grid-card' ); ?> data-aos="zoom-in" data-aos-delay="150">

							<a href="<?php the_permalink(); ?>" class="blog-grid-thumb">
								<?php if ( has_post_thumbnail() ) : ?>
									<?php the_post_thumbnail( 'large' ); ?>
								<?php else : ?>
									<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/placeholder.jpg" alt="<?php the_title_attribute(); ?>">
								<?php endif; ?>
							</a>

							<div class="blog-grid-content">

								<div class="blog-grid-meta">
									<?php
									$cat = get_the_category();
									if ( ! empty( $cat ) ) :
										$cat_link = get_category_link( $cat[0]->term_id );
									?>
										<a href="<?php echo esc_url( $cat_link ); ?>" class="blog-grid-badge">
											<?php echo esc_html( $cat[0]->name ); ?>
										</a>
									<?php endif; ?>

									<span class="blog-grid-date">
										<?php echo get_the_date(); ?>
									</span>
								</div>

								<h3 class="blog-grid-title">
									<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								</h3>

								<p class="blog-grid-excerpt">
									<?php echo wp_trim_words( get_the_excerpt(), 20 ); ?>
								</p>

								<a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>

							</div><!-- .blog-grid-content -->

						</article><!-- .blog-grid-card -->

					<?php endwhile; ?>

				</div><!-- .blog-modern-grid -->

				<div class="blog-grid-pagination">
					<?php
					the_posts_pagination( array(
						'prev_text' => '&laquo; Prev',
						'next_text' => 'Next &raquo;',
					) );
					?>
				</div>

			<?php else : ?>

				<p><?php esc_html_e( 'No posts found.', 'siteorigin-corp' ); ?></p>

			<?php endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_sidebar();
get_footer();