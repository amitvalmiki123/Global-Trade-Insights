# Global Trade Insights — Clazar-style Blog for SiteOrigin Corp child theme

Exact `clazar.io/blog` layout for the **blog page, category/tag/search pages and single posts**.
Header, footer and menus are **not touched**. Parent theme (siteorigin-corp) is **not modified**.

## Files → copy into `wp-content/themes/siteorigin-corp-child/`

| File | Purpose | Overwrites yours? |
|---|---|---|
| `home.php` | Blog page: hero → latest post → tabs/search → grid → View More → CTA | No (new) |
| `single.php` | Single article (Clazar layout) | **YES — rename your old `single.php` → `single-old.php.txt` first** |
| `category.php`, `tag.php`, `search.php` | Same grid on archive pages (used by header menu category links) | No (new) |
| `template-parts/gt-archive.php` | Shared listing for the 3 above | No (new) |
| `inc/blog-setup.php` | Helpers: assets, read time, AJAX filter, TOC, related posts | No (new) |
| `assets/css/blog.css`, `assets/js/blog.js` | Styles + behaviour | No (new) |

`header.php`, `footer.php`, `archive.php`, `index.php`, `style.css`, `functions.php` stay as they are.

## Activate — add ONE line at the very end of `functions.php`

```php
require get_stylesheet_directory() . '/inc/blog-setup.php';
```

## After install
1. **Settings → Reading** → set a **Posts page** (or front page shows latest posts).
2. Install **Regenerate Thumbnails**, run once (sizes: card 800×480, featured 1200×720, single hero 1600×800).
3. **Users → Profile** → add profile photo + short Biographical Info (shown as author role/bio).

## Behaviour (matches Clazar)
- **Latest post** — two separate blocks: gray text panel (read time, big title, author photo | date) + rounded image.
- **Tabs** — click a category → grid filters **via AJAX on the same page** (featured stays). Empty → plain **"Nothing found"**.
- **Search icon** — replaces the tab row with a full-width rounded **"Search with keyword"** input with ✕; filters as you type. Hero search does the same.
- **View More** — AJAX, respects current category/keyword.
- **Single post** (exact Clazar) — centered title block (`date | read time`, H1, "Last updated on"), then two columns:
  **left sticky** = Table of Contents (auto from your H2/H3; cyan bar + bold follows the heading you're reading) → author photo + name → Share (LinkedIn / X / copy link);
  **right** = "← Back to all articles" → featured image → article. Below: Related content (3 cards) → CTA band.
  No "Explore AI Summary", no right-hand promo card.
  Write posts normally in the editor — every H2/H3 you add becomes a TOC entry automatically.
- **Read time** — computed on every render from the post's current content (÷200 wpm).

Everything is pulled live from normal WordPress Posts / Categories / Users.

## Optional filters
```php
add_filter( 'gt_hero_kicker',  fn() => 'The Global Trade Insights Blog' );
add_filter( 'gt_hero_heading', fn() => 'Insights and tips to help you trade smarter' );
add_filter( 'gt_posts_per_page', fn() => 6 );
add_filter( 'gt_words_per_minute', fn() => 220 );
add_filter( 'gt_show_cta', '__return_false' );
add_filter( 'gt_cta_heading', fn() => '...' );  add_filter( 'gt_cta_primary_url', fn() => home_url('/contact/') );
add_filter( 'gt_side_card_title', fn() => '...' ); add_filter( 'gt_side_card_url', fn() => home_url('/subscribe/') );
```
