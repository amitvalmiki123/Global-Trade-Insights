<?php
/**
 * Global Trade Insights — Blog setup (Clazar-style blog, archives and single post).
 *
 * Activate by adding this ONE line at the end of the child theme's functions.php:
 *
 *     require get_stylesheet_directory() . '/inc/blog-setup.php';
 *
 * Standard WordPress APIs only; the SiteOrigin Corp parent theme is not modified.
 *
 * @package siteorigin-corp-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------- 0. Which views use the Clazar layout ---------- */
function gt_is_blog_view() {
	return is_home() || is_category() || is_tag() || is_search() || is_singular( 'post' );
}

/* ---------- 1. Assets ---------- */
function gt_blog_enqueue_assets() {
	if ( ! gt_is_blog_view() ) {
		return;
	}
	wp_enqueue_style(
    'gt-red-hat-display',
    'https://fonts.googleapis.com/css2?family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&display=swap',
    array(),
    null
);
	wp_enqueue_style( 'gt-blog', get_stylesheet_directory_uri() . '/assets/css/blog.css', array(), '3.0.0' );
	wp_enqueue_script( 'gt-blog', get_stylesheet_directory_uri() . '/assets/js/blog.js', array(), '3.0.0', true );
	wp_localize_script( 'gt-blog', 'gtBlog', array( 'ajaxUrl' => admin_url( 'admin-ajax.php' ) ) );
}
add_action( 'wp_enqueue_scripts', 'gt_blog_enqueue_assets' );

function gt_blog_body_class( $classes ) {
	if ( gt_is_blog_view() ) {
		$classes[] = 'gt-blog-page';
	}
	return $classes;
}
add_filter( 'body_class', 'gt_blog_body_class' );

/* ---------- 2. Image sizes ---------- */
function gt_blog_image_sizes() {
	add_image_size( 'gt-blog-card', 800, 480, true );       // grid card 5:3
	add_image_size( 'gt-blog-featured', 1200, 720, true );  // latest post 5:3
	add_image_size( 'gt-blog-hero', 1600, 800, true );      // single post 2:1
}
add_action( 'after_setup_theme', 'gt_blog_image_sizes' );

/* ---------- 3. Real-time reading time ---------- */
function gt_reading_time( $post_id = null ) {
	$content = wp_strip_all_tags( strip_shortcodes( get_post_field( 'post_content', $post_id ) ) );
	$wpm     = max( 1, (int) apply_filters( 'gt_words_per_minute', 200 ) );
	return max( 1, (int) ceil( str_word_count( $content ) / $wpm ) );
}

/* ---------- 4. Helpers ---------- */
function gt_blog_home_url() {
	$posts_page = (int) get_option( 'page_for_posts' );
	return $posts_page ? get_permalink( $posts_page ) : home_url( '/' );
}
function gt_posts_per_page() {
	return (int) apply_filters( 'gt_posts_per_page', 6 );
}

/**
 * Categories shown as tabs — pulled live from Posts → Categories.
 * Default order: alphabetical. To customise:
 *   add_filter( 'gt_tab_categories_args', fn( $a ) => $a + array( 'orderby' => 'count', 'order' => 'DESC' ) );
 *   add_filter( 'gt_tab_categories_args', fn( $a ) => $a + array( 'exclude' => array( 12 ) ) ); // hide a category
 */
function gt_tab_categories() {
	$args = apply_filters( 'gt_tab_categories_args', array( 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ) );
	return get_categories( $args );
}
function gt_author_avatar( $size = 24 ) {
	return get_avatar( get_the_author_meta( 'ID' ), $size * 2, '', get_the_author(), array( 'class' => 'gt-avatar', 'loading' => 'lazy' ) );
}

/* ---------- 5. Category tabs (category / tag / search pages — link-based) ---------- */
function gt_render_category_tabs() {
	$current = is_category() ? get_queried_object_id() : 0;
	?>
	<div class="gt-tabs-wrap">
		<nav class="gt-tabs">
			<a class="gt-tab<?php echo is_home() ? ' is-active' : ''; ?>" href="<?php echo esc_url( gt_blog_home_url() ); ?>"><?php esc_html_e( 'All', 'siteorigin-corp-child' ); ?></a>
			<?php foreach ( gt_tab_categories() as $cat ) : ?>
				<a class="gt-tab<?php echo ( $cat->term_id === $current ) ? ' is-active' : ''; ?>" href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
			<?php endforeach; ?>
		</nav>
		<a class="gt-tabs__search" href="<?php echo esc_url( gt_blog_home_url() . '#gt-archive' ); ?>" aria-label="<?php esc_attr_e( 'Search posts', 'siteorigin-corp-child' ); ?>">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
		</a>
	</div>
	<?php
}

/* ---------- 6. Grid card ---------- */
function gt_render_post_card() {
	?>
	<article <?php post_class( 'gt-card' ); ?>>
		<a class="gt-card__media" href="<?php the_permalink(); ?>">
			<?php if ( has_post_thumbnail() ) the_post_thumbnail( 'gt-blog-card', array( 'loading' => 'lazy' ) ); ?>
		</a>
		<div class="gt-card__body">
			<div class="gt-card__meta">
				<span><?php echo esc_html( get_the_date( 'F j, Y' ) ); ?></span>
				<span><?php echo esc_html( gt_reading_time() ); ?> min read</span>
			</div>
			<h3 class="gt-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
			<span class="gt-card__author"><?php echo gt_author_avatar( 22 ); // phpcs:ignore ?><?php echo esc_html( get_the_author() ); ?></span>
		</div>
	</article>
	<?php
}

/* ---------- 7. Featured (latest) post — two separate blocks like Clazar ---------- */
function gt_render_featured_post() {
	?>
	<article <?php post_class( 'gt-featured' ); ?>>
		<div class="gt-featured__body">
			<span class="gt-featured__read"><?php echo esc_html( gt_reading_time() ); ?> min read</span>
			<h2 class="gt-featured__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			<div class="gt-featured__meta">
				<span class="gt-featured__author"><?php echo gt_author_avatar( 32 ); // phpcs:ignore ?><?php echo esc_html( get_the_author() ); ?></span>
				<span class="gt-featured__divider" aria-hidden="true"></span>
				<span><?php echo esc_html( get_the_date( 'F j, Y' ) ); ?></span>
			</div>
		</div>
		<a class="gt-featured__media" href="<?php the_permalink(); ?>">
			<?php if ( has_post_thumbnail() ) the_post_thumbnail( 'gt-blog-featured' ); ?>
		</a>
	</article>
	<?php
}

/* ---------- 8. CTA band ---------- */
function gt_render_cta() {
	?>
	<section class="gt-cta gt-bleed">
		<h2 class="gt-cta__title"><?php echo esc_html( apply_filters( 'gt_cta_heading', 'Ready to stay ahead in global trade?' ) ); ?></h2>
		<div class="gt-cta__actions">
			<a class="gt-btn gt-btn--orange" href="<?php echo esc_url( apply_filters( 'gt_cta_primary_url', home_url( '/contact/' ) ) ); ?>"><?php echo esc_html( apply_filters( 'gt_cta_primary_label', 'Get Started' ) ); ?></a>
			<a class="gt-btn gt-btn--outline" href="<?php echo esc_url( apply_filters( 'gt_cta_secondary_url', home_url( '/about/' ) ) ); ?>"><?php echo esc_html( apply_filters( 'gt_cta_secondary_label', 'See How It Works' ) ); ?></a>
		</div>
	</section>
	<?php
}

/* ---------- 9. AJAX: filter grid (category + keyword + page) — used by home.php ---------- */
function gt_filter_posts() {
	$page     = max( 1, isset( $_POST['page'] ) ? absint( $_POST['page'] ) : 1 );
	$per_page = max( 1, isset( $_POST['perPage'] ) ? absint( $_POST['perPage'] ) : gt_posts_per_page() );
	$cat      = isset( $_POST['cat'] ) ? absint( $_POST['cat'] ) : 0;
	$search   = isset( $_POST['s'] ) ? sanitize_text_field( wp_unslash( $_POST['s'] ) ) : '';

	$latest_id = 0;
	if ( ! $cat && '' === $search ) {
		$latest    = get_posts( array( 'post_type' => 'post', 'numberposts' => 1, 'fields' => 'ids' ) );
		$latest_id = $latest ? (int) $latest[0] : 0;
	}

	$args = array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => $per_page,
		'paged'               => $page,
		'ignore_sticky_posts' => true,
	);
	if ( $latest_id ) $args['post__not_in'] = array( $latest_id ); // "All" view: featured post is already shown
	if ( $cat )       $args['cat']          = $cat;
	if ( $search )    $args['s']            = $search;

	$query = new WP_Query( $args );
	ob_start();
	while ( $query->have_posts() ) {
		$query->the_post();
		gt_render_post_card();
	}
	wp_reset_postdata();

	wp_send_json_success(
		array(
			'html'    => ob_get_clean(),
			'found'   => (int) $query->found_posts,
			'hasMore' => $page < (int) $query->max_num_pages,
		)
	);
}
add_action( 'wp_ajax_gt_filter_posts', 'gt_filter_posts' );
add_action( 'wp_ajax_nopriv_gt_filter_posts', 'gt_filter_posts' );

/* ---------- 10. AJAX: load more for category / tag / search pages (main-query style) ---------- */
function gt_load_more() {
	$page     = isset( $_POST['page'] ) ? absint( $_POST['page'] ) : 1;
	$per_page = isset( $_POST['perPage'] ) ? absint( $_POST['perPage'] ) : gt_posts_per_page();
	$cat      = isset( $_POST['cat'] ) ? absint( $_POST['cat'] ) : 0;
	$search   = isset( $_POST['s'] ) ? sanitize_text_field( wp_unslash( $_POST['s'] ) ) : '';

	$args = array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => $per_page, 'paged' => $page, 'ignore_sticky_posts' => true );
	if ( $cat )    $args['cat'] = $cat;
	if ( $search ) $args['s']   = $search;

	$query = new WP_Query( $args );
	while ( $query->have_posts() ) {
		$query->the_post();
		gt_render_post_card();
	}
	wp_reset_postdata();
	wp_die();
}
add_action( 'wp_ajax_gt_load_more', 'gt_load_more' );
add_action( 'wp_ajax_nopriv_gt_load_more', 'gt_load_more' );

/* ---------- 11. Single post: auto Table of Contents from h2/h3 ---------- */
/** Build a unique, URL-safe id for a heading (handles duplicate heading text). */
function gt_heading_id( $text, &$used ) {
	$base = sanitize_title( wp_strip_all_tags( $text ) );
	if ( '' === $base ) {
		$base = 'section';
	}
	$id = $base;
	$n  = 2;
	while ( isset( $used[ $id ] ) ) {
		$id = $base . '-' . $n++;
	}
	$used[ $id ] = true;
	return $id;
}

function gt_add_heading_ids( $content ) {
	if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}
	$used = array();
	return preg_replace_callback(
		'/<h([23])([^>]*)>(.*?)<\/h\1>/is',
		function ( $m ) use ( &$used ) {
			if ( preg_match( '/\sid=["\']([^"\']+)["\']/i', $m[2], $existing ) ) {
				$used[ $existing[1] ] = true;
				return $m[0];
			}
			$id = gt_heading_id( $m[3], $used );
			return sprintf( '<h%1$s%2$s id="%3$s">%4$s</h%1$s>', $m[1], $m[2], esc_attr( $id ), $m[3] );
		},
		$content
	);
}
add_filter( 'the_content', 'gt_add_heading_ids', 20 );

/** Read the TOC from already-filtered content (ids were added by gt_add_heading_ids). */
function gt_get_toc( $content ) {
	preg_match_all( '/<h([23])([^>]*)>(.*?)<\/h\1>/is', $content, $matches, PREG_SET_ORDER );
	$items = array();
	$used  = array();
	foreach ( $matches as $m ) {
		$text = trim( wp_strip_all_tags( $m[3] ) );
		if ( '' === $text ) continue;
		if ( preg_match( '/\sid=["\']([^"\']+)["\']/i', $m[2], $existing ) ) {
			$id          = $existing[1];
			$used[ $id ] = true;
		} else {
			$id = gt_heading_id( $text, $used );
		}
		$items[] = array( 'level' => (int) $m[1], 'id' => $id, 'text' => $text );
	}
	return $items;
}

/* ---------- 12. Single post: related posts (same category first) ---------- */
function gt_related_posts( $post_id, $count = 3 ) {
	$cats = wp_get_post_categories( $post_id );
	$args = array( 'post_type' => 'post', 'posts_per_page' => $count, 'post__not_in' => array( $post_id ), 'ignore_sticky_posts' => true, 'no_found_rows' => true );
	if ( $cats ) $args['category__in'] = $cats;
	$q = new WP_Query( $args );
	if ( $q->post_count < $count ) {
		$exclude = array_merge( array( $post_id ), wp_list_pluck( $q->posts, 'ID' ) );
		$more    = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => $count - $q->post_count, 'post__not_in' => $exclude, 'ignore_sticky_posts' => true, 'no_found_rows' => true ) );
		$q->posts      = array_merge( $q->posts, $more->posts );
		$q->post_count = count( $q->posts );
	}
	return $q;
}