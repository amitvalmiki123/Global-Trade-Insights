<?php
/**
 * Shared Clazar-style listing for category / tag / search pages.
 * Loaded by category.php, tag.php and search.php via get_template_part().
 * Uses the MAIN query, so all standard WP behaviour (categories, search terms,
 * posts_per_page, pre_get_posts filters, SEO plugins) keeps working.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $wp_query;

if ( is_search() ) {
	$gt_kicker = __( 'Search results', 'siteorigin-corp-child' );
	/* translators: %s: search query */
	$gt_title  = sprintf( __( 'Results for “%s”', 'siteorigin-corp-child' ), get_search_query() );
} else {
	$gt_kicker = is_tag() ? __( 'Tag', 'siteorigin-corp-child' ) : __( 'Category', 'siteorigin-corp-child' );
	$gt_title  = single_term_title( '', false );
}

$gt_per_page  = (int) get_query_var( 'posts_per_page' );
$gt_max_pages = (int) $wp_query->max_num_pages;
$gt_cat_id    = is_category() ? (int) get_queried_object_id() : 0;
?>

<div id="primary" class="content-area gt-blog">
	<main id="main" class="site-main">

		<!-- HERO (compact) -->
		<section class="gt-hero gt-hero--compact gt-bleed">
			<div class="gt-hero__inner">
				<p class="gt-hero__kicker"><?php echo esc_html( $gt_kicker ); ?></p>
				<h1 class="gt-hero__title"><?php echo esc_html( $gt_title ); ?></h1>
				<?php if ( ! is_search() && term_description() ) : ?>
					<p class="gt-hero__desc"><?php echo wp_kses_post( wp_strip_all_tags( term_description() ) ); ?></p>
				<?php endif; ?>

				<form role="search" method="get" class="gt-hero__form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
					<input type="search" name="s" placeholder="<?php esc_attr_e( 'Search articles', 'siteorigin-corp-child' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" />
					<button type="submit"><?php esc_html_e( 'Search', 'siteorigin-corp-child' ); ?></button>
				</form>
			</div>
		</section>

		<div class="gt-container">
			<section class="gt-archive gt-archive--tight">
				<?php gt_render_category_tabs(); ?>

				<div class="gt-grid" id="gt-grid">
					<?php
					if ( have_posts() ) :
						while ( have_posts() ) :
							the_post();
							gt_render_post_card();
						endwhile;
					else :
						?>
						<div class="gt-empty">
							<p class="gt-empty__title"><?php esc_html_e( 'No articles found', 'siteorigin-corp-child' ); ?></p>
							<p class="gt-empty__sub"><?php esc_html_e( 'Try a different keyword or category.', 'siteorigin-corp-child' ); ?></p>
							<a class="gt-load-more" href="<?php echo esc_url( gt_blog_home_url() ); ?>"><?php esc_html_e( 'All articles', 'siteorigin-corp-child' ); ?></a>
						</div>
						<?php
					endif;
					?>
				</div>

				<?php if ( $gt_max_pages > 1 ) : ?>
					<div class="gt-load-more-wrap">
						<button class="gt-load-more" id="gt-load-more" type="button"
							data-page="1"
							data-max="<?php echo esc_attr( $gt_max_pages ); ?>"
							data-per-page="<?php echo esc_attr( $gt_per_page ); ?>"
							data-skip="0"
							data-cat="<?php echo esc_attr( $gt_cat_id ); ?>"
							data-s="<?php echo esc_attr( get_search_query() ); ?>">
							<?php esc_html_e( 'View More', 'siteorigin-corp-child' ); ?>
						</button>
					</div>
				<?php endif; ?>
			</section>
		</div>

	</main><!-- #main -->
</div><!-- #primary -->
