<?php
/**
 * Search results — Clazar-style grid.
 * Both hero search boxes and the tab search icon submit here.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
get_template_part( 'template-parts/gt-archive' );
get_footer();
