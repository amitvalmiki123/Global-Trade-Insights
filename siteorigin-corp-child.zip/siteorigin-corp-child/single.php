<?php
/**
 * Single post — exact Clazar article layout.
 *
 * ⚠️ Replaces the child theme's existing single.php (rename the old one to
 *    single-old.php.txt as a backup first). header.php / footer.php are yours.
 *
 * Layout (clazar.io/blog/<post>):
 *   ┌──────────────────────────────────────────────────────┐
 *   │   date | read time  ·  H1 (centered)  ·  Last updated │
 *   ├────────────────┬─────────────────────────────────────┤
 *   │ Table of       │ ← Back to all articles              │
 *   │ Contents       │ [featured image]                    │
 *   │ (sticky, cyan  │ article content (H2/H3 update TOC   │
 *   │  active bar)   │  as you scroll)                     │
 *   │ author         │                                     │
 *   │ Share          │                                     │
 *   ├────────────────┴─────────────────────────────────────┤
 *   │ Related content (3 cards)  →  CTA band               │
 *   └──────────────────────────────────────────────────────┘
 * No "Explore AI Summary", no right-hand promo card.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	$gt_content   = apply_filters( 'the_content', get_the_content() );
	$gt_toc       = gt_get_toc( $gt_content );
	$gt_updated   = ( get_the_modified_time( 'U' ) - get_the_time( 'U' ) ) > DAY_IN_SECONDS;
	$gt_permalink = get_permalink();
	$gt_share_txt = rawurlencode( get_the_title() );
	?>

	<div id="primary" class="content-area gt-blog gt-single">
		<main id="main" class="site-main">

			<article id="post-<?php the_ID(); ?>" <?php post_class( 'gt-article' ); ?>>

				<!-- Title block — centered, full width -->
				<header class="gt-single__head">
					<div class="gt-single__meta">
						<span><?php echo esc_html( get_the_date( 'M j, Y' ) ); ?></span>
						<span class="gt-single__sep" aria-hidden="true">|</span>
						<span><?php echo esc_html( gt_reading_time() ); ?> min read</span>
					</div>
					<h1 class="gt-single__title"><?php the_title(); ?></h1>
					<?php if ( $gt_updated ) : ?>
						<div class="gt-single__updated"><?php printf( esc_html__( 'Last updated on %s', 'siteorigin-corp-child' ), esc_html( get_the_modified_date( 'M j, Y' ) ) ); ?></div>
					<?php endif; ?>
				</header>

				<!-- Two columns -->
				<div class="gt-container gt-single__layout">

					<!-- LEFT: sticky TOC + author + share -->
					<aside class="gt-single__side">
						<div class="gt-single__sticky">
							<?php if ( $gt_toc ) : ?>
								<div class="gt-toc" data-gt-toc>
									<div class="gt-toc__label"><?php esc_html_e( 'Table of Contents', 'siteorigin-corp-child' ); ?></div>
									<ul>
										<?php foreach ( $gt_toc as $item ) : ?>
											<li class="gt-toc__item gt-toc__item--h<?php echo (int) $item['level']; ?>">
												<a href="#<?php echo esc_attr( $item['id'] ); ?>"><?php echo esc_html( $item['text'] ); ?></a>
											</li>
										<?php endforeach; ?>
									</ul>
								</div>
							<?php endif; ?>

							<div class="gt-single__author">
								<?php echo gt_author_avatar( 40 ); // phpcs:ignore ?>
								<span><?php the_author(); ?></span>
							</div>

							<div class="gt-share">
								<div class="gt-share__label"><?php esc_html_e( 'Share', 'siteorigin-corp-child' ); ?></div>
								<div class="gt-share__links">
									<a href="<?php echo esc_url( 'https://www.linkedin.com/sharing/share-offsite/?url=' . rawurlencode( $gt_permalink ) ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Share on LinkedIn">
										<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.36V9h3.41v1.56h.05c.47-.9 1.63-1.85 3.36-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29ZM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12ZM7.12 20.45H3.56V9h3.56v11.45Z"/></svg>
									</a>
									<a href="<?php echo esc_url( 'https://twitter.com/intent/tweet?url=' . rawurlencode( $gt_permalink ) . '&text=' . $gt_share_txt ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Share on X">
										<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.9 2H22l-7.5 8.6L23.3 22h-6.9l-5.4-7-6.2 7H1.7l8-9.2L1.3 2h7l4.9 6.4L18.9 2Zm-1.2 18h1.9L7.4 3.9H5.3L17.7 20Z"/></svg>
									</a>
									<button type="button" data-gt-copy="<?php echo esc_attr( $gt_permalink ); ?>" aria-label="<?php esc_attr_e( 'Copy link', 'siteorigin-corp-child' ); ?>">
										<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10 13a5 5 0 0 0 7.07 0l3-3a5 5 0 0 0-7.07-7.07l-1.5 1.5M14 11a5 5 0 0 0-7.07 0l-3 3a5 5 0 0 0 7.07 7.07l1.5-1.5"/></svg>
									</button>
								</div>
							</div>
						</div>
					</aside>

					<!-- RIGHT: back link, image, content -->
					<div class="gt-single__main">
						<a class="gt-single__back" href="<?php echo esc_url( gt_blog_home_url() ); ?>">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg>
							<?php esc_html_e( 'Back to all articles', 'siteorigin-corp-child' ); ?>
						</a>

						<?php if ( has_post_thumbnail() ) : ?>
							<div class="gt-single__hero"><?php the_post_thumbnail( 'gt-blog-hero' ); ?></div>
						<?php endif; ?>

						<div class="gt-single__content entry-content">
							<?php echo $gt_content; // phpcs:ignore WordPress.Security.EscapeOutput — filtered by the_content ?>
							<?php wp_link_pages( array( 'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'siteorigin-corp-child' ), 'after' => '</div>' ) ); ?>

							<?php $gt_tags = get_the_tags(); if ( $gt_tags ) : ?>
								<div class="gt-single__tags">
									<?php foreach ( $gt_tags as $tag ) : ?>
										<a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>"><?php echo esc_html( $tag->name ); ?></a>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
						</div>

						<?php if ( comments_open() || get_comments_number() ) comments_template(); ?>
					</div>
				</div>
			</article>

			<!-- Related content -->
			<?php $gt_related = gt_related_posts( get_the_ID(), 3 ); if ( $gt_related->have_posts() ) : ?>
				<section class="gt-container gt-related">
					<h2 class="gt-related__title"><?php esc_html_e( 'Related content', 'siteorigin-corp-child' ); ?></h2>
					<div class="gt-grid gt-grid--related">
						<?php while ( $gt_related->have_posts() ) : $gt_related->the_post(); gt_render_post_card(); endwhile; wp_reset_postdata(); ?>
					</div>
				</section>
			<?php endif; ?>

			<?php if ( apply_filters( 'gt_show_cta', true ) ) gt_render_cta(); ?>

		</main>
	</div>

	<?php
endwhile;

get_footer();
