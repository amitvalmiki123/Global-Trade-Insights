<?php
/**
 * The template for displaying all single posts
 *
 * @license GPL 2.0
 */
get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

<?php
while ( have_posts() ) :
	the_post();
	?>

	<?php if ( has_post_thumbnail() ) :
		$image_id  = get_post_thumbnail_id();
		$image_url = wp_get_attachment_url( $image_id );
		$image_alt = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
	?>
	<div class="single-blog-banner">
		<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>" class="banner-image" />
		<div class="banner-overlay"></div>
		<div class="banner-content">
			<div class="container">

				<div class="banner-meta">
					<?php
					$categories = get_the_category();
					if ( ! empty( $categories ) ) :
					?>
						<a href="<?php echo esc_url( get_category_link( $categories[0]->term_id ) ); ?>" class="cat-name">
							<?php echo esc_html( $categories[0]->name ); ?>
						</a>
					<?php endif; ?>
					<span class="post-date"><?php echo get_the_date(); ?></span>
				</div>

				<h1 class="post-heading"><?php the_title(); ?></h1>

			</div>
		</div>
	</div>
	<?php else : ?>
		<div class="single-blog-banner single-blog-banner-noimg">
			<div class="banner-content">
				<div class="container">
					<h1 class="post-heading"><?php the_title(); ?></h1>
				</div>
			</div>
		</div>
	<?php endif; ?>

	<div class="single-blog-row">
		<div class="corp-container single-blog-content">

			<div class="extra-content">
				<?php
				the_content();

				wp_link_pages( array(
					'before' => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'siteorigin-corp' ) . '</span>',
					'after'  => '</div>',
					'link_before' => '<span>',
					'link_after'  => '</span>',
				) );
				?>
			</div>

			<?php if ( class_exists( 'Jetpack_Likes' ) ) :
				$custom_likes = new Jetpack_Likes();
				echo $custom_likes->post_likes( '' );
			endif; ?>

			<?php if ( class_exists( 'Jetpack' ) && Jetpack::is_module_active( 'sharedaddy' ) ) :
				echo sharing_display();
			endif; ?>

			<?php if ( siteorigin_setting( 'navigation_post' ) ) :
				siteorigin_corp_the_post_navigation();
			endif; ?>

			<?php if ( siteorigin_setting( 'blog_post_author_box' ) ) :
				siteorigin_corp_author_box();
			endif; ?>

			<?php
			$categories = get_the_category();
			if ( $categories ) :
				$category_ids = array();
				foreach ( $categories as $category ) {
					$category_ids[] = $category->term_id;
				}
				$related_args = array(
					'post_type'      => 'post',
					'posts_per_page' => 3,
					'post__not_in'   => array( get_the_ID() ),
					'category__in'   => $category_ids,
				);
				$related_query = new WP_Query( $related_args );
				if ( $related_query->have_posts() ) :
			?>
				<div class="related-posts-section">
					<h3>Related Posts</h3>
					<div class="related-posts-grid">

						<?php while ( $related_query->have_posts() ) : $related_query->the_post(); ?>
							<div class="related-post-item">
								<a href="<?php the_permalink(); ?>">
									<?php if ( has_post_thumbnail() ) : ?>
										<?php the_post_thumbnail( 'medium' ); ?>
									<?php endif; ?>
									<h4><?php the_title(); ?></h4>
								</a>
							</div>
						<?php endwhile; ?>

					</div>
				</div>
			<?php
				endif;
				wp_reset_postdata();
			endif;
			?>

			<?php if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif; ?>

		</div><!-- .single-blog-content -->
	</div><!-- .single-blog-row -->

<?php endwhile; ?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_sidebar();
get_footer();
